#include <stdio.h>
#include <math.h>
#include <stdbool.h>

// Define global constants
#define STUDENTS 4
#define GRADE_CATEGORIES 5
#define CATEGORIES "1. Learning Activity 2. Homework 3. Project 4. Midterm 5.Final"
const int MAX_GRADE = 125;
const int MIN_GRADE = 0;
const double GRADE_CATEGORY_WEIGHT[] = { 0.1, 0.3, 0.3, 0.15, .15 };

//*** Function Prototypes ***//
int getValidGrade(int MIN_GRADE, int MAX_GRADE);
void displayInstructions();
void displayCategoryWeights(const double gradeWeights[]);
void fillGradesArray(int studentGradesArray[STUDENTS][GRADE_CATEGORIES], size_t SIZE);
void print2DArray(const int twoDArray[STUDENTS][GRADE_CATEGORIES]);
void printFinalGradesArray(const double studentAverageGrades[]);
void calculateFinalGrades(const int array[][GRADE_CATEGORIES], double studentAverageGrades[]);
double calculateClassAverage(const double studentAverageGrades[]);

int main()
{
	// Print instructions and grade weights for each category
	displayInstructions();
	displayCategoryWeights(GRADE_CATEGORY_WEIGHT);

	// Create 2D array to hold grades
	int studentGradesArray[STUDENTS][GRADE_CATEGORIES];

	// Calls function to fill grades array
	fillGradesArray(studentGradesArray, STUDENTS);

	// Print the contents of the grades array
	print2DArray(studentGradesArray);

	// Create array to store students grade averages and initialize to 0
	double studentAverageGrades[STUDENTS] = { 0 };

	// Calculate Student Averages, send both arrays to function
	calculateFinalGrades(studentGradesArray, studentAverageGrades);

	// Display Student Averages
	printFinalGradesArray(studentAverageGrades);
	
	// Catch the value returned from classAverage function
	double classAverage = calculateClassAverage(studentAverageGrades);
	printf("\nClass Average is %.1lf\n", classAverage);
} // end Main

double calculateClassAverage(const double studentAverageGrades[])
{
	double total = 0;
	// iterate through studentAverageGrades to calculate class avg
	for (size_t t = 0; t < STUDENTS; t++) {
		total += studentAverageGrades[t];
	}
	double classAverage = total / STUDENTS;
	return classAverage;
}
void printFinalGradesArray(const double array[])
{
	// Print final grades for each student in array
	printf("%s", "\nFinal grades for each student:\n");
	for (size_t t = 0; t < STUDENTS; t++)
	{
		double finalGrade = array[t];
		printf("Student%zu %.1lf ", t + 1, finalGrade);

		// Based on grade, find letter grade & print
		if (finalGrade >= 90) {
			puts("A");
		}
		else if ((80 <= finalGrade) && (finalGrade < 90)) {
			puts("B");
		}
		else if ((70 <= finalGrade) && (finalGrade < 80)) {
			puts("C");
		}
		else if ((60 <= finalGrade) && (finalGrade < 70)) {
			puts("D");
		}
		else {
			puts("F");
		}
	}

}
void calculateFinalGrades(const int array[][GRADE_CATEGORIES], double studentFinalGrades[])
{
	// Declare and init. variable for calculating average
	double studentAverage = 0;
	// Iterate throught 2D studentGradesArray,calculate student's 
	// average grade and fill 1D-array for averages of all students
	for (size_t t = 0; t < STUDENTS; t++) {
		for (size_t j = 0; j < GRADE_CATEGORIES; j++) {
			studentAverage = studentAverage + (GRADE_CATEGORY_WEIGHT[j] * array[t][j]);
		}
		// At the end of each row: calculate student avg and place into avgsArray
		studentFinalGrades[t] = studentAverage;
		studentAverage = 0;
	}

}
void print2DArray(const int twoDArray[STUDENTS][GRADE_CATEGORIES])

{
	printf("%s", "\nGrades entered for each student");
	// For every row
	for (size_t t = 0; t < STUDENTS; t++)
	{
		printf("\nStudent%zu:  ", t + 1);
		// For every location in a row
		for (size_t j = 0; j < GRADE_CATEGORIES; j++) {
			printf("%d ", twoDArray[t][j]);
		}
		//printf("\nStudent%zu:", t+1);
	}
	printf("%s", "\n");
} // End print2DArray

int getValidGrade(int MIN_GRADE, int MAX_GRADE)
{
	bool isValid = 0;
	unsigned int grade = 0;

	do {
		int input = 0;
		// Read user input
		printf("%s", "\n");
		unsigned int scanfRetVal = scanf("%d", &input);

		// Clear the buffer
		while ((getchar()) != '\n');
		// If RetVal is 1 and input within range, change bool & set grade
		if (scanfRetVal == 1) {
			if ((input >= 0) && (input <= MAX_GRADE)) {
				grade = input;
				isValid = 1;
			}
			else {
				printf("%s ", "Invalid input. Must be between 0 - 105.");
			}
		}
		else {
			printf("%s", "You did not enter an integer.");
		}
	} while (!isValid);

	return grade;
} // End getValidGrade

void displayCategoryWeights(const double array[])
{
	for (size_t t = 0; t < GRADE_CATEGORIES; t++) {
		printf("Category %zu weight is %.2lf\n", t, array[t]);
	}
} // End displayCategoryWeights

void displayInstructions()
{
	printf("%s", "This program will calculate the grades for these categories:\n");
	puts(CATEGORIES);
	printf("The category weights are:\n");
} // End displayInstructions

void fillGradesArray(int studentGradesArray[STUDENTS][GRADE_CATEGORIES], size_t SIZE)
{
	printf("%s", "\nThe correct order to enter grades for each student is:\n");
	puts(CATEGORIES);

	for (size_t t = 0; t < SIZE; t++)
	{
		//printf("%s", "TEST1\n");
		for (size_t j = 0; j < GRADE_CATEGORIES; j++)
		{
			printf("\nEnter the grade for each category for student %zu, category %zu", t + 1, j + 1);
			studentGradesArray[t][j] = getValidGrade(MIN_GRADE, MAX_GRADE);
		}
	}
} // End fillGradesArray