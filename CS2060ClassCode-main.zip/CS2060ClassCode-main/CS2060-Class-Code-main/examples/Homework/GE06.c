#define SIZE 80
#include <stdio.h>
#include <string.h>


typedef struct organization
{
	char orgName[SIZE];
	char purpose[SIZE];
	char firstAndLastName[SIZE];
	double goalAmount;

}Organization;

void setUpOrganization(Organization* someOrg);
void displayOrganization(const Organization someOrg);

int main(void)
{
	Organization newOrg;
	setUpOrganization(&newOrg);

	printStruct(newOrg);

} // main

void setUpOrganization(Organization* someOrg) {

	printf("%s", "Enter the name of your Organization.");
	fgets(someOrg->orgName, SIZE, stdin);

	printf("%s", "Enter the purpose of your Organization,");
	fgets(someOrg->purpose, SIZE, stdin);

	printf("%s", "Enter your first and last name.");
	fgets(someOrg->firstAndLastName, SIZE, stdin);

	printf("%s", "Enter your Organizations goal amount to be raised.");
	scanf("%lf", someOrg->goalAmount);

} // setUpOrg funct

void displayOrganization(Organization someOrg) {
	printf("%s", someOrg.orgName);
	printf("%s", someOrg.purpose);
	printf("%s", someOrg.firstAndLastName);
	printf("%lf", someOrg.goalAmount);

}