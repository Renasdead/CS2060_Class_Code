#include <stdbool.h>
#include <stdio.h>
#include <math.h>

// Declare global constants
#define MIN_HOURS_AT_FLAT_RATE 3
#define MIN_FLAT_RATE_CHARGE 3
#define ADDITIONAL_HOURS_RATE .75
#define MAX_HOURS_ALLOWED 24
#define MAX_CHARGE 12

//*** Function Prototypes ***//
int getValidInput();
double calculateParkingCharge(int a);
void displayTransaction(int carNumber, int hours, double charge);
void displayEndSummary(int numCars, int totalHours, double totalCharges);

int main() 
{
	// Variable to track totals
	unsigned int numCars = 0;
	unsigned int totalHours = 0;
	double totalCharges = 0;


	// get validated input
	int hours = getValidInput();

	// if not the sentinel value continue loop
	while (hours != -1) 
	{
		// increment numCars so it doesn't start with zero
		numCars++;

		// get charge for hours
		double charge = calculateParkingCharge(hours);
		displayTransaction(numCars, hours, charge);

		// Update totals
		totalCharges = totalCharges + charge;
		totalHours = totalHours + hours;
		
		// Get next validated input
		hours = getValidInput();
		
	} 
	// End main while loop, Display totals

	displayEndSummary(numCars, totalHours, totalCharges);
	return 0;
} // main

int getValidInput() 
{
	double input = 0;
	bool isValid = 0;
	int hours = 0;
	do {
		// Read user input
		printf("%s", "Enter the number of hours the car was parked or enter -1 to quit.\n");
		unsigned int scanfRetVal = scanf("%lf", &input);
		
		// Clear the buffer
		while ((getchar()) != '\n');
		if (scanfRetVal == 1) {
			if ( (input == -1) || ((input > 0) && (input <= MAX_HOURS_ALLOWED)) ) {
				hours = ceil(input);
				isValid = 1;
			}
			else {
				printf("%s", "Invalid duration. Must be ");
			}
		}
		else {
			printf("%s", "You did not enter an integer.");
		}
	} while (!isValid);

	return hours;
} // end getValidInput

double calculateParkingCharge(int hoursParked) 
{
	double charge = 0.0;

	if (hoursParked <= MIN_HOURS_AT_FLAT_RATE) {
		charge = MIN_FLAT_RATE_CHARGE;
	}
	else {
		charge = (((hoursParked - MIN_HOURS_AT_FLAT_RATE) * ADDITIONAL_HOURS_RATE) + MIN_FLAT_RATE_CHARGE);
	}
	if (charge >= MAX_CHARGE) {
		charge = MAX_CHARGE;
	}

	return charge;
} // end calculateParkingCharge

void displayTransaction(int numCars, int hours, double charge) 
{
	printf("Car: #%d       Hours: %d    Charge: $%.2lf\n", numCars, hours, charge);

} // end displayTransaction

void displayEndSummary(int numCars, int totalHours, double totalCharges) {
	printf("\n%s", "Parking Garage Summary\n");
	if (numCars == 0) {
		printf("\n%s", "No cars were parked.");
	}
	else {
		printf("%s", "Total Cars:     Total Hours:     Total Charges:\n");
		printf("     %-16d%-15d$%-8.2lf", numCars, totalHours, totalCharges);
	}
} // end displayEndSummary