/* This program simulates a website which (while in setUpMode) allows users to create an organization
 * which can receive donations from users (while in donationsMode). If while in donationsMode, the 
 * program is expecting input for donation amount, Q/q is entered, the program exits donationsMode
 * and enters admin mode where the admin Email and password must be entered correctly in two attempts
 * or less.
*/

#define SIZE 80
#define MIN_DOUBLE 1
#define MIN_PASS_LENGTH 7
#define ZIP_LENGTH 5
#define CARD_FEE .031
#define MIN_DBL_VAL 0
#define FILE_PATH C:\CS2060files\

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <float.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>


// Structure that represents on Organization
typedef struct organization
{
	char orgName[SIZE];
	char purpose[SIZE];
	char firstAndLastName[SIZE];
	char orgAdminEmail[SIZE];
	char orgAdminPassword[SIZE];
	double goalAmount;
	double numDonations;
	double totalAmountRaised;
	double totalCardFees;
	char URL[SIZE];

	// Self referential. Pointer to next Pet struct 
	struct organization* nextOrgPtr;

}Organization;


// Function Prototypes in Alphabetical order
bool adminReportMode(const Organization* orgPtr);
bool confirmChoice(const char* someString, unsigned int printOption);
void createOrgURL(Organization* orgPtr);
void createReceipt(Organization* someOrg);
void displayOrganization(const Organization* someOrgPtr);
void displayCreatedOrgInfo(const Organization* organizationPtr);
void donationsMode(Organization* orgPtr);
void displayFundraiserDonationMode(const Organization* orgPtr);
void getValidZipCode(char* zipCode);
void insertOrg(Organization** headPtr);
void printList(Organization** listPtr);
void removeNewlineChar(char* ptrInputStr);
void setUpOrganization(Organization* someOrg);
int stringCompareIgnoreCase(const char* stringPtr, const char* otherStringPtr);
void stringToUppercase(char* stringPtr);
bool validateDouble(char array[], double* doubleValuePtr, int doubleMin);
bool validateEmail(const char* passwordStr);
bool validatePassword(const char* passwordStr);
bool yesOrNo();


int main(void)
{
	// Create new Organization and call setUpOrganization to get details
	Organization newOrg;

	// Call setUpOrganization to get data for struct memebers from admin user
	setUpOrganization(&newOrg);

	// Call displayCreatedOrgInfo to display data entered by admin user
	displayCreatedOrgInfo(&newOrg);

	// While input for donation amount != Q/q, continue collecting donations
	donationsMode(&newOrg);

} // main

// Report mode for administrator after successfull login, prints stats/totals
bool adminReportMode(const Organization* orgPtr)
{
	unsigned int numEmailAttempts = 3;
	unsigned int numPassAttempts = 3;
	char emailStr[SIZE]; // create char array
	char passwordStr[SIZE];
	

	bool loggedIn = false;

	// while still have Email Attempts
	while ( (numEmailAttempts > 0) )
	{
		// prompt for email
		printf("%s", "\nEnter admin Email.");

		// Read in user input as character array and remove newline character
		fgets(emailStr, SIZE, stdin);
		removeNewlineChar(emailStr);
		numEmailAttempts--;

		// if emailStr matches adminEmail
		if (strcmp(orgPtr->orgAdminEmail, emailStr) == 0)
		{
			numEmailAttempts = 0;

			// while still have Password Attempts
			while (numPassAttempts > 0)
			{
				printf("%s", "\nEnter admin password.");
				// get password, decrement attempts
				fgets(passwordStr, SIZE, stdin);
				removeNewlineChar(passwordStr);
				numPassAttempts--;

				// If passwordStr matches admin password
				if (strcmp(orgPtr->orgAdminPassword, passwordStr) == 0)
				{

					loggedIn = true;
					
					// Display Final Statistics
					printf("\nOrganization name: %s", orgPtr->orgName);
					printf("\nTotal number of donations: %.2lf", orgPtr->numDonations);
					printf("\nTotal amount raised: %.2lf", orgPtr->totalAmountRaised);
					printf("\nTotal amount paid for credit card processing: %.2lf", orgPtr->totalCardFees);

					// If successful login, set attempts to zero to prevent looping
					numEmailAttempts = 0;
					numPassAttempts = 0;
				}
				else {
					// Password incorrect
					printf("\nIncorrect admin password. Number attempts left : %lu", numPassAttempts);
				}
			}
		}
		else {
			printf("\nIncorrect admin email. Number attempts left : %lu", numEmailAttempts);
		}
	} // main while-loop
	printf("%s", "\nGoing back to donations mode..");
	return loggedIn;
} //  end adminReportMode
/* Function that takes in a pointer to a String which can be printed along with(y)es or (n)o prompt.
Also receives an int to indicate which promt should repeat. If printOption = 1, then "Is (this) correct?" will print.
If printOption = 0, then "Enter (y)es or (n)o?" will print. Returns boolean*/
bool confirmChoice(const char* someString, unsigned int printOption)
{
	// boolean to control loop while user attempts to enter input correctly
	bool isThisCorrect = false;
	// Boolean value for whether or not the user asnwers (y)es or (n)o
	bool isInputValid = false;

	// char array to hold user's input
	char selection[SIZE];

	// loop while user input is not a Y/y or N/n
	while (!isInputValid)
	{
		if (printOption == 0) {

			printf("\n%s %s", someString, "\nEnter (y)es or (n)o ");
		}
		else if (printOption == 1)
		{
			printf("\nIs %s correct?", someString);
		}

		// prompt user for letter
		fgets(selection, SIZE, stdin);
		removeNewlineChar(selection);

		// If valid input(Y/y) or (N/n), change boolean for valid
		if ((selection[0] == 'Y') || (selection[0] == 'y')) {
			isInputValid = true;
			isThisCorrect = true;
		}
		else if ((selection[0] == 'N') || (selection[0] == 'n')) {
			isInputValid = true;
			printf("%s", "\nWas not correct, try again. ");
		}
		else {
			printf("%s", "\nInvalid input. Must enter (Y/y) for yes or N/n for no. ");
		}
	}
	return isThisCorrect;
}
// Takes in a pointer to an organization and uses orgName and urlEnd to create a URL 
// where spaces in orgName are replaced with (-)
void createOrgURL(Organization* someOrgPtr)
{
	// Make a copy of the string so we can initialize it to first part of URL
	strncpy(someOrgPtr->URL, "https:donate.com/", SIZE);

	// Make a copy of the string so we can initialize it to last part of URL
	char urlEnd[SIZE] = "?form=popup#\n";

	// Create a copy of orgName before replacing spaces with dashes
	char orgNameCpy[SIZE];
	strncpy(orgNameCpy, someOrgPtr->orgName, sizeof(someOrgPtr->orgName));

	// use strchr to locate occurrences of spaces in orgNameCpy
	char* spcPtr;
	spcPtr = strchr(orgNameCpy, ' ');

	// while strchr successfully finds spaces
	while (spcPtr != NULL) {

		// replace the space with dash
		*spcPtr = '-';

		// find next space
		spcPtr = strchr(orgNameCpy, ' ');
	}

	// Concatenate strings to make URL
	strcat(someOrgPtr->URL, orgNameCpy);
	removeNewlineChar(&someOrgPtr->URL);
	strcat(someOrgPtr->URL, urlEnd);

	//removeNewlineChar(&someOrgPtr->URL);

} // end createOrgURL

void createReceipt(Organization* someOrg) 
{
	
	// Print receipt for donation
	printf("Organization: %s.", someOrg->orgName);
	//printf(" Donation Amount : %.2lf", donation);

	// create struct to get date & time
	time_t t = time(NULL);
	struct tm date = *localtime(&t);

	unsigned int hour = date.tm_hour;

	printf("\nDonation Date: [%ld/%ld/%ld] -", date.tm_mon, date.tm_mday, date.tm_year + 1900);

	if (date.tm_hour >= 12) {
		if (hour != 12) {
			hour = hour - 12;
		}

		printf("[%ld:", hour);
		printf("%ld]", date.tm_min);

		puts("PM");
	}
	else {
		if (hour == 0) {
			hour = 12;
		}
		puts("AM");
	}
}

// Displays to Admin the information of an organization that has just been set up
void displayCreatedOrgInfo(const Organization* orgPtr)
{
	printf("\nThank you %s. The url to raise funds for %s is %s ", orgPtr->firstAndLastName, orgPtr->orgName, orgPtr->URL);

}

// Displays FULL fundraiser information for donators to see while in donationsMode
void displayFundraiserDonationMode(const Organization* orgPtr)
{
	// Display URL, fundraiser info and current totals for donations
	printf("\n\n\n%s", orgPtr->URL);
	puts("MAKE A DIFFERENCE BY YOUR DONATION");
	printf("\nOrganization: %s. ", orgPtr->orgName);
	printf("\nPurpose: %s. ", orgPtr->purpose);
	printf("\nWe currently have raised [%.2lf].", orgPtr->totalAmountRaised);

	double percentGoalRaised = orgPtr->totalAmountRaised / orgPtr->goalAmount;

	// If GOAL MET, DISPLAY "We have reached our goal but can still use the donations."
	if (orgPtr->totalAmountRaised > orgPtr->goalAmount) {
		printf("%s", "\nWe have reached our goal but can still use the donations.");
	}
	else {
		// IF GOAL NOT MET, DISPLAY 
		printf(" We are [%.2lf] towards our goal of [%.2lf]", percentGoalRaised, orgPtr->goalAmount);
	}

} // end displayFundraiserDonationMode

// Displays each organization struct member
void displayOrganization(const Organization* someOrgPtr)
{
	printf("%s", someOrgPtr->orgName);
	printf("%s", someOrgPtr->purpose);
	printf("%s", someOrgPtr->firstAndLastName);
	printf("%.2lf", someOrgPtr->goalAmount);
	printf("\n%s", someOrgPtr->URL);

}

/* Simulates Mode for taking in donations and donator information. Takes in pointer to an Organization. Returns void.*/
void donationsMode(Organization* orgPtr)
{
	bool quit = false;
	bool gotValidDouble = false;
	bool adminLoggedIn = false;

	// Loop continues while input is not admin code (Q/q)!!
	while (!quit)
	{
		// Display fundraiser info for Donations Mode
		displayFundraiserDonationMode(orgPtr);

		char inputStr[SIZE]; // create char array
		printf("%s", "\nEnter your donation amount $");


		// Read in user input for DONATION, store in character array
		fgets(inputStr, SIZE, stdin);
		removeNewlineChar(inputStr);

		// Check if the adminMode code was entered
		if ((strlen(inputStr) == 1) && ((inputStr[0] == 'Q') || (inputStr[0] == 'q')))
		{
			adminLoggedIn = adminReportMode(orgPtr);
			if (adminLoggedIn) {
				quit = true;
			}
		}
		else // If not admin code
		{
			double donation = 0;

			// Loop until user enters valid double
			while (!gotValidDouble) 
			{	// Read in input again, and 
				gotValidDouble = validateDouble(inputStr, &donation, MIN_DBL_VAL);
				
				if (!gotValidDouble) 
				{
					printf("\n%lf is not a valid donation amount! Try again.", donation);
					fgets(inputStr, SIZE, stdin);

					// Call removeNewlineChar
					removeNewlineChar(inputStr);
				}
			}
			
			// Get full name of donor
			char donatorFullName[SIZE];

			// Get first name and remove newline character
			printf("%s", "Enter your first and last name: ");
			fgets(donatorFullName, SIZE, stdin);
			removeNewlineChar(donatorFullName);

			// Create pointer to zipCode
			char zipCode[SIZE];
			printf("%s", "\nEnter your five digit Zip Code: \n");
			getValidZipCode(zipCode);

			// Calculate card fee and update totalCardFees
			double cardProcessingFee = 0;

			// Calculate card fee
			cardProcessingFee = (donation * CARD_FEE);

			// Calculate actual amount to be donated
			double amountDonated = donation - cardProcessingFee;

			// Update Org totals for totalDonations & totalCardFees
			orgPtr->totalCardFees += cardProcessingFee;
			orgPtr->totalAmountRaised += donation;

			// Thank for donation and inform them of card processing fee
			printf("\nThank you for your donation. There is a 2.9 percent credit card processing fee of $%.2lf. $%.2lf will be donated.", cardProcessingFee, amountDonated);

			// Ask if donor wants a receipt			
			char wantReceiptPrompt[SIZE] = "Do you want a receipt? ";
			
			unsigned int printOrNot = 0;

			// Call confirmChoice function
			bool wantsReceipt = confirmChoice(wantReceiptPrompt, printOrNot);

			// If user wants receipt, print donation details
			if (wantsReceipt)
			{
				// Print receipt for donation
				printf("Organization: %s.", orgPtr->orgName);
				printf(" Donation Amount : %.2lf", donation);

				// create struct to get date & time
				time_t t = time(NULL);
				struct tm date = *localtime(&t);

				unsigned int hour = date.tm_hour;

				printf("\nDonation Date: [%ld/%ld/%ld] -", date.tm_mon, date.tm_mday, date.tm_year + 1900);

				// Determine if AM or PM, append to receipt time
				if (date.tm_hour >= 12) {
					if (hour != 12) {
						hour = hour - 12;
					}

					printf("[%ld:", hour);
					printf("%ld]", date.tm_min);
					puts("PM");
				}
				else {
					if (hour == 0) {
						hour = 12;
					}
					puts("AM");
				}
				// Append receipt details to file as well //----------------------------------------------------------------------------------->


			}
			else {
				printf("%s", "\nThank you for your donation. Going back to donations mode.");
			}
		} // end else

	} // end while loop
}// end donationsMode

// Function takes in a character pointer and gets a valid zipcode (length of 5, first digit != 0). returns void
void getValidZipCode(char* zipCode)
{
	// Read in ZipCode and remove newline character
	char buffer[SIZE];
	fgets(buffer, SIZE, stdin);
	removeNewlineChar(buffer);

	printf("\nZip entered is: %s", buffer);

	// Check length first
	if (strlen(buffer) == 5) {

		char firstDigit = buffer[0];

		// Check if first character is a Zero
		if (firstDigit != '0') {

			// Update bool flag and set validated zip
			strncpy(zipCode, buffer, SIZE);
		}
		else {
			printf("%s", "\nZip entered cannot with a zero. Try again.");
		}
	}
	else {
		printf("%s", "\nZip entered does not contain correct number of digits. Try again.");
	}

} // end getValidZipCode

// Prints all Organization structures in LinkedList 
void printList(Organization** listPtr)
{
	// If list is not empty (headptr != null)
	if (listPtr != NULL)
	{
		// Create currentPtr and set to the headPtr
		Organization* currentPtr = *listPtr;

		// While-loop to iterate through LinkedList
		while (currentPtr != NULL)//------------------------------------------ CHECK currentPtr
		{
			// Print and move currentPtr to next pet struct
			displayOrganization(currentPtr);
			// Shift currentPtr down the LinkedList
			currentPtr = currentPtr->nextOrgPtr;
		}
	}
	else
	{
		puts("List is empty");
	}
} // end printList

// Sets up an Organization with all struct member fields filled by admin.
void setUpOrganization(Organization* someOrg)
{
	// Initialize total counters to 0 so not filled with garbage values
	someOrg->goalAmount = 0;
	someOrg->numDonations = 0;
	someOrg->totalAmountRaised = 0;
	someOrg->totalCardFees = 0;

	printf("%s", "Enter the name of your Organization. ");
	fgets(someOrg->orgName, SIZE, stdin);

	// remove newline char in orgName
	removeNewlineChar(someOrg->orgName);

	printf("%s", "Enter the purpose of your Organization. ");
	fgets(someOrg->purpose, SIZE, stdin);
	removeNewlineChar(someOrg->purpose);

	printf("%s", "Enter your first and last name. ");
	fgets(someOrg->firstAndLastName, SIZE, stdin);

	// remove newline char in firstAndLastName array
	removeNewlineChar(someOrg->firstAndLastName);

	// Get valid double, then assign to struct member
	bool isValid = false;
	char goalStr[SIZE]; // create char array

	while (!isValid) {
		printf("\n%s", "Enter your Organization's goal amount to be raised. ");

		// remove newline char in orgAdminEmail
		fgets(goalStr, SIZE, stdin);
		removeNewlineChar(goalStr);

		isValid = validateDouble(goalStr, &someOrg->goalAmount, MIN_DBL_VAL);
	}

	// bool flag for valid email
	bool isYourEmailCorrect = false;

	char emailStr[SIZE];

	// Loop while confirm choice is N/n
	while (!isYourEmailCorrect)
	{
		// validateEmail
		bool validEmail = false;

		while (!validEmail) {
			// Get email address for admin
			printf("\n%s", "Enter the email address to be associated with this organization. ");

			fgets(emailStr, SIZE, stdin);
			removeNewlineChar(emailStr);

			validEmail = validateEmail(emailStr);

		}

		// call confirmChoice to continue looping until user's email is correct
		// send email to print back to user along with printChoice option
		unsigned int printOption = 1;
		isYourEmailCorrect = confirmChoice(emailStr, printOption);

	} // isYourEmailCorrect

	// Send validated email to struct member
	strncpy(someOrg->orgAdminEmail, emailStr, SIZE);

	bool validPassword = false;
	char passwordStr[SIZE];

	// Get orgAdminPassword
	while (!validPassword)
	{
		// Get email address for admin
		printf("\n%s", "Enter a password for the organization admin account. ");


		fgets(passwordStr, SIZE, stdin);
		removeNewlineChar(passwordStr);

		validPassword = validatePassword(passwordStr);

	}
	// Send validated email to struct member
	strncpy(someOrg->orgAdminPassword, passwordStr, SIZE);

	// Create URL for organization
	createOrgURL(someOrg);

	// CREATE RECEIPT FILE //--------------------------------------------------------------------------------->
	//FILE* receiptFile = fopen(receipts, "a");
	//C:\Users\Kelly\Documents\GitHub\CS2060ClassCode\CS2060-Class-Code-main\examples\Homework\receipts.txt

} // end setUpOrg

// Inserts org into LinkedList in Sorted alphabetical order
void insertOrg(Organization** headPtr)
{
	bool addAnotherOrg = true;
	bool yaeOrNae;

	Organization* newOrg;

	while (addAnotherOrg)
	{

		// creating a Ptr to a new node and allocate sufficient memory
		Organization* newOrgPtr = malloc(sizeof(Organization));

		// call setUpOrg(), send new struct Ptr to set up that struct
		setUpOrganization(newOrgPtr);

		// if not the end of the linkedList
		if (newOrgPtr != NULL)
		{
			// assign name to newOrgPtr.name
			//strncpy(newOrgPtr->orgName, orgNameUppercase, SIZE);

			// 
			newOrgPtr->nextOrgPtr = NULL;

			// 
			Organization* previousPtr = NULL;
			// 
			Organization* currentPtr = *headPtr;

			// 
			while (currentPtr != NULL && (stringCompareIgnoreCase(currentPtr->orgName, newOrgPtr->orgName) < 0))
			{
				// 
				previousPtr = currentPtr;
				// 
				currentPtr = currentPtr->nextOrgPtr;
			}

			// If no pets in list
			if (previousPtr == NULL)
			{
				// assign head to the newPetPtr
				*headPtr = newOrgPtr;
			}
			else
			{
				// 
				previousPtr->nextOrgPtr = newOrgPtr;
			}
			// 
			newOrgPtr->nextOrgPtr = currentPtr;
		}
		else
		{
			printf("%s", "No memory to create node for Organization\n");
		}

		printf("%s", "\nDo you want to add another Organization? ");
		yaeOrNae = yesOrNo();

		if (!yaeOrNae) {
			addAnotherOrg = false;
		}
	} // while add another pet
} // end insertPet

void removeNewlineChar(char* inputStrPtr) {


	// calls strnlen function to determine length of char arrray inputStr
	size_t inputLength = strnlen(inputStrPtr, SIZE);

	// if inputLength is corrent length and the last character is a newline
	if ((inputLength <= SIZE - 1) && (inputStrPtr[inputLength - 1] == '\n')) {
		// clear the buffer
		//while (getchar() != '\n');
	}

	// if inputLength is above 0 and the last character in the array is a newline char
	if ((inputLength > 0) && (inputStrPtr[inputLength - 1] == '\n'))
	{
		// replace last character in array with null byte
		inputStrPtr[inputLength - 1] = '\0';
		// decrement inputLength
		//inputLength--;
	}


} // end removeNewlineChar

int stringCompareIgnoreCase(const char* stringPtr, const char* otherStringPtr) 
{
	int returnValue = 0;

	// Set up to make copies of both strings using strncpy
	char stringCopy[SIZE];
	char otherStringCopy[SIZE];
	
	// Copy strings over
	strncpy(stringCopy, stringPtr, SIZE);
	strncpy(otherStringCopy, otherStringPtr, SIZE);
	
	//convert to uppercase
	stringToUppercase(stringCopy);
	stringToUppercase(otherStringCopy);

	// call strncmp()
	returnValue = strcmp(stringCopy, otherStringCopy);

	return returnValue;

} // end stringCompareIgnoreCase

void stringToUppercase(char* stringPtr) {
	// For every character in the string
	for (int i = 0; i < strlen(stringPtr); i++)
	{
		stringPtr[i] = toupper(stringPtr[i]);
	}
}

// Write petlist to file
void writeReceiptToFile(const Organization* orgList, char* orgListFile)
{
	// Open the file for writing
	FILE* file = fopen(orgListFile, "a");

	if (file == NULL) {
		printf("%s", "\nFile could not be found. ");
	}
		
		fprintf(file, "%s\n", orgList->orgName);

		// create struct to get date & time
		time_t t = time(NULL);
		struct tm date = *localtime(&t);

		unsigned int hour = date.tm_hour;

		printf("\nDonation Date: [%ld/%ld/%ld] -", date.tm_mon, date.tm_mday, date.tm_year + 1900);

		if (date.tm_hour >= 12) {
			if (hour != 12) {
				hour = hour - 12;
			}

			printf("[%ld:", hour);
			printf("%ld]", date.tm_min);

			puts("PM");
		}
		else {
			if (hour == 0) {
				hour = 12;
			}
			puts("AM");

		}

} // end writePetsToFile

bool validateDouble(char inputStr[], double* doublePtr, int doubleMin)
{
	bool isValidDouble = false;

	// Convert to double using strtod
	char* endPtr;
	double doubleValue = strtod(inputStr, &endPtr);

	// Check that something was successfully entered
	if (endPtr == inputStr) {
		printf("%s is not a numeric value. Try again.\n", inputStr);
	}
	else if (*endPtr != '\0') // Test that the last character is a null byte to ensure all characters were included in conversion.
	{						  // If not a null byte, characters remain in the buffer.

		printf("\n%s had extra characters at end of input: %s\n", inputStr, endPtr);
	}
	else if ((doubleValue == DBL_MAX || doubleValue == DBL_MIN) && ERANGE == errno)
	{
		printf("\n%s", "Number is outside of normal range.");
	}
	else if (doubleValue < doubleMin) {
		printf("\n%s", "Value must be greater than 0.");
	}
	else if (*endPtr == '\0') {
		// SEND TO STRUCT MEMBER & update bool flag
		*doublePtr = doubleValue;
		isValidDouble = true;
	}

	return isValidDouble;
} // end getValidDouble

// Function validates that user entered password meets specific requirements. Takes in a const pointer to string
bool validateEmail(const char* emailStr)
{
	bool isValidPass = false;

	char chrAt = '@';
	char* retAt = strchr(emailStr, chrAt);

	char chrPeriod = '.';
	char* retPeriod = strchr(emailStr, chrPeriod);

	// Check passwordStr for @ symbol
	if (retAt == NULL) {
		printf("%s", "\nMust contain [@] symbol! ");
	}// Check if first character is an @ symbol
	else if (retAt == emailStr) {
		printf("%s", "\nCannot begin with [@]! ");
	}
	if ((retPeriod - retAt) > 1) {
		if (emailStr[strlen(emailStr) - 4] == chrPeriod) {
			isValidPass = true;
		}
	} else {
		printf("%s", "\nMust contain characters between \"@\" and \".\"!");
	}
	return isValidPass;
} // end validateEmail

bool validatePassword(const char* passwordStr) 
{
	// bool for whether passwordStr meets all requirments
	bool isValid = false;

	// bools for each requirement
	bool hasDigit = false;
	bool hasLower = false;
	bool hasUpper = false;

	// Check the length of the input
	if (strlen(passwordStr) >= MIN_PASS_LENGTH) 
	{
		// For-loop to check all characters for requirements
		for (int i = 0; i < strlen(passwordStr); i++) 
		{
			if (isdigit(passwordStr[i]))
			{
				hasDigit = true;
			}
			else if (islower(passwordStr[i]))
			{
				hasLower = true;
			}
			else if (isupper(passwordStr[i]))
			{
				hasUpper = true;
			}
		} // for-loop
		if (hasDigit)
		{
			if (hasUpper)
			{
				if (hasLower)
				{
					isValid = true;
				}
				else {
					printf("%s", "\nPassword must contain at least one lowercase character! ");
				}
			}
			else {
				printf("%s", "\nPassword must contain at least one uppercase character! ");
			}
		}
		else {
			printf("%s", "\nPassword must contain at least one digit! ");
		}
	}
	else {
		printf("%s", "\nPassword must be at least 7 characters long! ");
	}
	return isValid;
}

// Takes in no arguments, prompts the user for a (Y)es or (N)o and returns bool. Yes returns True, No returns False.
bool yesOrNo()
{
	// boolean to store Yes or No, True of False
	bool answer = false;
	// Boolean value for whether or not the user asnwers (y)es or (n)o
	bool isValidSelection = false;

	// char array to hold user's input
	char selection[SIZE];

	printf("%s", "\nPlease enter Y/y for yes or N/n for no. ");

	// loop while user input is not a Y/y or N/n
	while (!isValidSelection)
	{

		// prompt user for letter
		fgets(selection, SIZE, stdin);
		removeNewlineChar(selection);

		// If valid input(Y/y) or (N/n), change boolean for valid
		if ((selection[0] == 'Y') || (selection[0] == 'y')) {
			isValidSelection = true;
			answer = true;
		}
		else if ((selection[0] == 'N') || (selection[0] == 'n')) {
			isValidSelection = true;
			answer = false;
		}
		else {
			printf("%s", "\nInvalid input. Must enter (Y/y) for yes or N/n for no. ");
		}
	}
	return answer;
}

