/* Description: This program will allow the user to enter pet names and ages where memory
 * will be allocated and they will be stored alphabetically in a linked list. After pets
 * are entered the user can remove the pet and memory will be deallocated.
 * Before the program ends all the memory will be deallocated for any remaining pets.
 *
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define SIZE 80


 // Structure for pet
typedef struct pet
{
	char name[SIZE];
	unsigned int age;
	// Self referential. Pointer to next Pet struct 
	struct pet* nextPetPtr;
}Pet;

void printList(Pet** listPtr);
void insertPet(Pet** headPtr);
void deletePet(Pet** headPtr);
char validateYesNo();
void stringToUppercase(char* stringPtr);


int main(void)
{
	//puts("\n\n");

	// Create 
	Pet* headPetPtr = NULL;

	insertPet(&headPetPtr);

	printList(&headPetPtr);

	deletePet(&headPetPtr);

	printList(&headPetPtr);

}
// Function to convert entire string to uppercase characters
void stringToUppercase(char* stringPtr)
{
	// For every character in the string
	for (int i = 0; i < strlen(stringPtr); i++) 
	{
		stringPtr[i] = toupper(stringPtr[i]);
	}

} // end stringToUppercase


// 
void insertPet(Pet** headPtr)
{
	bool addAnotherPet = true;
	char yesOrNo;

	Pet* newPet;

	while (addAnotherPet) 
	{

		// creating a Ptr to a new node and allocate sufficient memory
		Pet* newPetPtr = malloc(sizeof(Pet));

		// Char array to store pet name entered by user
		char petNameUppercase[SIZE];
		unsigned int petAge = 0;

		// scan in petNameToAdd, make a copy
		printf("%s", "Enter pet name: ");
		char petNameToAdd[SIZE];
		scanf("%s", &petNameToAdd);

		// Read in pet's age
		printf("%s", "Enter pet age: ");
		scanf("%lu", &newPetPtr->age);


		// Copy string before converting to uppercase, petNameUppercase is the string
		// that will be uppercase after conversion
		strncpy(petNameUppercase, petNameToAdd, SIZE);


		// convert to all uppercase characters
		stringToUppercase(&petNameUppercase);
			

			

		// if not the end of the linkedList
		if (newPetPtr != NULL)
		{
			// assign name to newPetPtr.name
			strncpy(newPetPtr->name, petNameUppercase, SIZE);

			// 
			newPetPtr->nextPetPtr = NULL;

			// 
			Pet* previousPtr = NULL;
			// 
			Pet* currentPtr = *headPtr;

			// 
			while (currentPtr != NULL && (strcmp(currentPtr->name, petNameUppercase) < 0))
			{
				// 
				previousPtr = currentPtr;
				// 
				currentPtr = currentPtr->nextPetPtr;
			}
				
			// If no pets in list
			if (previousPtr == NULL)
			{
				// assign head to the newPetPtr
				*headPtr = newPetPtr;
			}
			else
			{
				// 
				previousPtr->nextPetPtr = newPetPtr;
			}

			// 
			newPetPtr->nextPetPtr = currentPtr;
		}
		else
		{
			printf("%s", "No memory to create node for pet\n");
		}


		// 
		printf("%s", "\nDo you want to add another pet? ");
		yesOrNo = validateYesNo();
		
		if (yesOrNo == 'n') {
			addAnotherPet = false;
		 }

	} // while add another pet


} // end insertPet


// function to delete pet, takes in char* to string representing name of pet to be deleted
void deletePet(Pet** headPtr)
{

	char yesOrNo = ' ';

	// Create & initialize two pointers to move down LinkedList
	Pet* previousPtr = NULL;
	Pet* currentPtr = *headPtr;
	
	char nameToDelete[SIZE];

	bool continueDeletingPets = true;

	while (continueDeletingPets)
	{
		printf("%s", "\nEnter name of pet in the list to delete ");

		// Get name of pet from user, clear buffer, and the convert to Uppercase
		
		scanf("%s", nameToDelete);
		while (getchar() != '\n');
		stringToUppercase(nameToDelete);

		// assign the string comparison return value to int for easier stmts
		int compReturnValue = strcmp(currentPtr->name, nameToDelete);

		// If headPtr is pointing to a pet
		if (*headPtr != NULL)
		{
			// If pet to delete matches pet at headPtr (THIS MEANS FIRST PET IN LIST IS A MATCH)
			if (compReturnValue == 0)//<---------------------------------------------------------JUST CHANGED TO == 0
			{
				// move the head pointer to next pet in list, so dont lose head of list
				*headPtr = (*headPtr)->nextPetPtr;
				
				// deallocate memory and set currentPtr to null
				free(currentPtr);
				currentPtr = NULL;
			}
			else // If pet to delete is not first in List
			{
				// While current != null and match is not found
				while (currentPtr != NULL && strcmp(currentPtr->name, nameToDelete) != 0)
				{
					// Move pointers down linkedlist until match is found
					previousPtr = currentPtr;
					currentPtr = currentPtr->nextPetPtr;
				}
				compReturnValue = strcmp(currentPtr->name, nameToDelete);


				if (currentPtr == NULL) {
					printf("Pet %s was not found!", nameToDelete);
				}
				else {
					if (previousPtr == NULL) {
						headPtr = currentPtr->nextPetPtr;
					}
					else {
						previousPtr->nextPetPtr = currentPtr->nextPetPtr;
					}
				}
				//// 	If currentPtr points to a pet whos name matches the pet to delete
				//if ( (currentPtr != NULL) && (compReturnValue == 0) )//<---------------------------------
				//{
				//	// if current is still at the headPtr, move head to next before deleting head
				//	if (currentPtr == *headPtr) 
				//	{
				//		// TO NOT LOSE HEAD IF DELETING FIRST IN LIST
				//		*headPtr = (*headPtr)->nextPetPtr;
				//		free(currentPtr);
				//		currentPtr = NULL;
				//	}
				//	previousPtr->nextPetPtr = currentPtr;
				//	

				//	free(currentPtr);
				//	currentPtr = NULL;

				//	//// Print petList to show pet is deleted
				//	//printList(headPtr);
				//}
				//else if( (compReturnValue == 0) && (currentPtr->nextPetPtr == NULL) )
				//{
				//	previousPtr->nextPetPtr = NULL;
				//	
				//}
				//else {
				//	//puts("Pet was not found!");
				//}
			}
		}
		else
		{
			puts("There aren't any Pets in this list!");
		}
		printList(headPtr);

		// Ask if there are more pets to delete
		printf("%s", "\nDo you want to delete another pet? ");
		yesOrNo = validateYesNo();

		if (yesOrNo == 'n') {
			continueDeletingPets = false;
		}

	} // continueDeletingPets

	//printList(headPtr);

} //deletePet

// Write petlist to file
void writePetsToFile(const Pet* petList, char* petListFile) 
{
	// Open the file for writing
	FILE* file = fopen(petListFile, "w");
	if (file == NULL) {
		printf("%s", "\nFile could not be found. ");
	}
	while (petList != NULL) {
		fprintf(file, "%s, %d\n", petList->name, petList->age);
	}

} // end writePetsToFile

// 
void printList(Pet** listPtr)
{
	// If list is not empty (headptr != null)
	if (listPtr != NULL)
	{
		// Create currentPtr and set to the headPtr
		Pet* currentPtr = *listPtr;

		// 
		while (currentPtr->nextPetPtr != NULL)//<----------------------------------------------- CHANGED from currentPtr TO currentPtr->nextPetPtr
		{
			// Print and move currentPtr to next pet struct
			printf("\n%s, age: %lu\n", currentPtr->name, currentPtr->age);

			currentPtr = currentPtr->nextPetPtr;
		}
	}
	else
	{
		puts("List is empty");
	}
} // end printList


// 
char validateYesNo() {
	char validYesNo;

	do {
		puts("Please enter (y)es or (n)o:");
		scanf("%c", &validYesNo);

		while (getchar() != '\n');

		validYesNo = tolower(validYesNo);

	} while (validYesNo != 'y' && validYesNo != 'n');

	return  validYesNo;
} //End validateYesNo